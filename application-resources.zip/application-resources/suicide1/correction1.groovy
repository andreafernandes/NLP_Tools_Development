for(doc in docs){
inputAS = doc.getAnnotations("SecondAnnotator");
    for(annot in inputAS){     
            annot.getFeatures().put("Attempt_Act","")
            annot.getFeatures().put("Ideation_Thoughts","")
            annot.getFeatures().put("Risk_High_Low","")
            annot.getFeatures().put("SuicideEventNotFitInWithOtherCat","")
            annot.getFeatures().put("Wishes_Intent_Threat_Plan_Note","")
   }
   }