separator = ','


for (doc in docs) {
firstAS = doc.getAnnotations('FirstAnnotator')
suicideAnns = firstAS.get('SuicideSentence')

str = ''

for (ann in suicideAnns) {
    fm = ann.getFeatures()
    attemptAct = fm.get('Attempt_Act')
    ideaThoughts = fm.get('Ideation_Thoughts')
    docName = doc.getName()
    sentence = Utils.stringFor(doc, ann)
    str += docName + separator + sentence + separator + attemptAct + separator + ideaThoughts + '\n'
}


 
 fileName = "new_results.csv"
 
 new File("T:\\Andrea_suicide\\Newfolder\\", fileName) << str
}